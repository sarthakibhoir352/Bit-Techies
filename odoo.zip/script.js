// Global variables
let currentUser = null;
let products = [];
let cart = [];
let purchases = [];
let isLoginMode = false;

// Navigation history
let navigationHistory = [];
let currentHistoryIndex = -1;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    console.log('EcoFinds initializing...');
    loadData();
    updateUI();
    setupEventListeners();
    
    // Force refresh products on page load
    setTimeout(() => {
        if (document.getElementById('browse-page').classList.contains('active')) {
            loadProducts();
        }
    }, 100);
});

// Data persistence functions
function saveData() {
    localStorage.setItem('ecofinds_users', JSON.stringify(users || []));
    localStorage.setItem('ecofinds_products', JSON.stringify(products));
    localStorage.setItem('ecofinds_cart', JSON.stringify(cart));
    localStorage.setItem('ecofinds_purchases', JSON.stringify(purchases));
    localStorage.setItem('ecofinds_currentUser', JSON.stringify(currentUser));
}

function loadData() {
    // Clear old data and start fresh
    localStorage.removeItem('ecofinds_products');
    
    users = JSON.parse(localStorage.getItem('ecofinds_users')) || [];
    products = [];
    cart = JSON.parse(localStorage.getItem('ecofinds_cart')) || [];
    purchases = JSON.parse(localStorage.getItem('ecofinds_purchases')) || [];
    currentUser = JSON.parse(localStorage.getItem('ecofinds_currentUser')) || null;
    
    // Always add fresh sample data
    addSampleData();
    console.log('Fresh sample data loaded:', products.length, 'products');
}

function addSampleData() {
    // Clear existing products and add fresh sample data
    products = [];
    
    const sampleProducts = [
        {
            id: 1,
            title: "Vintage Wooden Chair",
            description: "Beautiful vintage wooden chair in excellent condition. Perfect for dining room or study. Handcrafted with sustainable materials.",
            category: "furniture",
            price: 45.99,
            image: "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f8f0'/%3E%3Cpath d='M150 50L200 100H100L150 50Z' fill='%232c5530'/%3E%3Crect x='100' y='100' width='100' height='150' fill='%234a7c59'/%3E%3Crect x='120' y='250' width='60' height='10' fill='%236b8e6b'/%3E%3Ctext x='150' y='180' text-anchor='middle' fill='white' font-size='16' font-family='Arial'%3EChair%3C/text%3E%3C/svg%3E",
            sellerId: "sample_user",
            sellerName: "Sample User"
        },
        {
            id: 2,
            title: "iPhone 12 Pro",
            description: "iPhone 12 Pro 128GB in Space Gray. Lightly used, comes with original charger. Eco-friendly packaging included.",
            category: "electronics",
            price: 699.99,
            image: "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f8f0'/%3E%3Crect x='50' y='50' width='200' height='200' rx='20' fill='%232c5530'/%3E%3Crect x='60' y='70' width='180' height='120' rx='10' fill='%234a7c59'/%3E%3Ccircle cx='150' cy='200' r='15' fill='%236b8e6b'/%3E%3Ctext x='150' y='140' text-anchor='middle' fill='white' font-size='14' font-family='Arial'%3EiPhone%3C/text%3E%3C/svg%3E",
            sellerId: "sample_user",
            sellerName: "Sample User"
        },
        {
            id: 3,
            title: "Designer Jeans",
            description: "High-quality designer jeans, size 32. Worn only a few times, like new condition. Made from organic cotton.",
            category: "clothing",
            price: 29.99,
            image: "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f8f0'/%3E%3Cpath d='M100 50L200 50L200 250L100 250Z' fill='%234a7c59'/%3E%3Cpath d='M110 60L200 60L200 240L110 240Z' fill='%236b8e6b'/%3E%3Ccircle cx='130' cy='100' r='10' fill='%232c5530'/%3E%3Ccircle cx='170' cy='100' r='10' fill='%232c5530'/%3E%3Ctext x='150' y='180' text-anchor='middle' fill='white' font-size='16' font-family='Arial'%3EJeans%3C/text%3E%3C/svg%3E",
            sellerId: "sample_user",
            sellerName: "Sample User"
        },
        {
            id: 4,
            title: "Programming Books Set",
            description: "Collection of 5 programming books covering JavaScript, Python, and React. Perfect for eco-conscious developers.",
            category: "books",
            price: 39.99,
            image: "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f8f0'/%3E%3Crect x='80' y='40' width='140' height='200' rx='5' fill='%232c5530'/%3E%3Crect x='90' y='50' width='120' height='180' rx='3' fill='%234a7c59'/%3E%3Ctext x='150' y='130' text-anchor='middle' fill='white' font-size='14' font-family='Arial'%3ECoding%3C/text%3E%3C/svg%3E",
            sellerId: "sample_user",
            sellerName: "Sample User"
        },
        {
            id: 5,
            title: "Yoga Mat",
            description: "Professional yoga mat, non-slip surface. Used for 6 months, still in great condition. Made from natural rubber.",
            category: "sports",
            price: 19.99,
            image: "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f8f0'/%3E%3Crect x='50' y='80' width='200' height='140' rx='10' fill='%234a7c59'/%3E%3Ccircle cx='150' cy='150' r='30' fill='%236b8e6b'/%3E%3Ctext x='150' y='155' text-anchor='middle' fill='white' font-size='16' font-family='Arial'%3EYoga%3C/text%3E%3C/svg%3E",
            sellerId: "sample_user",
            sellerName: "Sample User"
        },
        {
            id: 6,
            title: "Eco-Friendly Water Bottle",
            description: "Stainless steel water bottle with bamboo cap. Keeps drinks cold for 24 hours. Perfect for sustainable living.",
            category: "sports",
            price: 24.99,
            image: "data:image/svg+xml;charset=utf8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300' viewBox='0 0 300 300'%3E%3Crect width='300' height='300' fill='%23f0f8f0'/%3E%3Crect x='120' y='60' width='60' height='180' rx='5' fill='%234a7c59'/%3E%3Crect x='125' y='55' width='50' height='10' rx='5' fill='%236b8e6b'/%3E%3Ccircle cx='150' cy='240' r='8' fill='%232c5530'/%3E%3Ctext x='150' y='160' text-anchor='middle' fill='white' font-size='12' font-family='Arial'%3EBottle%3C/text%3E%3C/svg%3E",
            sellerId: "sample_user",
            sellerName: "Sample User"
        }
    ];
    
    products = sampleProducts;
    saveData();
    console.log('Sample data loaded:', products);
}

// User management
let users = [];

function registerUser(email, password, username) {
    const userExists = users.find(user => user.email === email);
    if (userExists) {
        alert('User with this email already exists!');
        return false;
    }
    
    const newUser = {
        id: Date.now().toString(),
        email,
        password,
        username,
        createdAt: new Date().toISOString()
    };
    
    users.push(newUser);
    currentUser = newUser;
    saveData();
    return true;
}

function loginUser(email, password) {
    const user = users.find(user => user.email === email && user.password === password);
    if (user) {
        currentUser = user;
        saveData();
        return true;
    }
    return false;
}

function logoutUser() {
    currentUser = null;
    cart = [];
    saveData();
    updateUI();
}

// UI Management
function showPage(pageId, addToHistory = true) {
    console.log('Showing page:', pageId);
    
    // Add to navigation history if not going back/forward
    if (addToHistory) {
        addToNavigationHistory(pageId);
    }
    
    // Hide all pages
    const pages = document.querySelectorAll('.page');
    pages.forEach(page => page.classList.remove('active'));
    
    // Show selected page
    const targetPage = document.getElementById(pageId + '-page');
    if (targetPage) {
        targetPage.classList.add('active');
        console.log('Page activated:', pageId);
    } else {
        console.error('Page not found:', pageId + '-page');
    }
    
    // Update breadcrumb
    updateBreadcrumb(pageId);
    
    // Update navigation buttons state
    updateNavigationButtons();
    
    // Update page content based on current page
    switch(pageId) {
        case 'browse':
            console.log('Loading browse page...');
            loadProducts();
            break;
        case 'my-listings':
            loadMyListings();
            break;
        case 'cart':
            loadCart();
            break;
        case 'purchases':
            loadPurchases();
            break;
        case 'dashboard':
            loadDashboard();
            break;
    }
}

function updateUI() {
    const authLink = document.getElementById('auth-link');
    const navMenu = document.querySelector('.nav-menu');
    
    if (currentUser) {
        authLink.textContent = 'Logout';
        authLink.onclick = () => {
            logoutUser();
            showPage('login');
        };
        
        // Show all navigation items
        navMenu.style.display = 'flex';
        
        // Show browse page by default for logged in users
        showPage('browse');
    } else {
        authLink.textContent = 'Login';
        authLink.onclick = () => showPage('login');
        
        // Hide navigation items except login
        const navLinks = navMenu.querySelectorAll('.nav-link');
        navLinks.forEach(link => {
            if (link.textContent !== 'Login') {
                link.style.display = 'none';
            }
        });
        
        // Show home page for non-logged in users
        showPage('home');
    }
}

// Event Listeners
function setupEventListeners() {
    // Auth form
    const authForm = document.getElementById('auth-form');
    authForm.addEventListener('submit', handleAuth);
    
    // Add product form
    const addProductForm = document.getElementById('add-product-form');
    addProductForm.addEventListener('submit', handleAddProduct);
    
    // Edit profile form
    const editProfileForm = document.getElementById('edit-profile-form');
    editProfileForm.addEventListener('submit', handleEditProfile);
    
    // Image upload
    const imageUpload = document.getElementById('product-image');
    imageUpload.addEventListener('change', handleImageUpload);
    
    // Hamburger menu
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('nav-menu');
    hamburger.addEventListener('click', () => {
        navMenu.classList.toggle('active');
    });
}

function handleAuth(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const username = document.getElementById('username').value;
    
    if (isLoginMode) {
        if (loginUser(email, password)) {
            alert('Login successful!');
            showPage('home');
            updateUI();
        } else {
            alert('Invalid email or password!');
        }
    } else {
        if (registerUser(email, password, username)) {
            alert('Registration successful!');
            showPage('home');
            updateUI();
        }
    }
}

function toggleAuth() {
    isLoginMode = !isLoginMode;
    const form = document.getElementById('auth-form');
    const submitBtn = form.querySelector('button[type="submit"]');
    const switchLink = form.querySelector('.auth-switch a');
    const usernameField = document.getElementById('username');
    
    if (isLoginMode) {
        submitBtn.textContent = 'Login';
        switchLink.textContent = 'Sign Up';
        usernameField.style.display = 'none';
    } else {
        submitBtn.textContent = 'Sign Up';
        switchLink.textContent = 'Login';
        usernameField.style.display = 'block';
    }
}

function handleAddProduct(e) {
    e.preventDefault();
    
    if (!currentUser) {
        alert('Please login to add a product!');
        return;
    }
    
    const title = document.getElementById('product-title').value;
    const category = document.getElementById('product-category').value;
    const description = document.getElementById('product-description').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const imageFile = document.getElementById('product-image').files[0];
    
    const newProduct = {
        id: Date.now(),
        title,
        category,
        description,
        price,
        image: null,
        sellerId: currentUser.id,
        sellerName: currentUser.username,
        createdAt: new Date().toISOString()
    };
    
    // Handle image upload
    if (imageFile) {
        const reader = new FileReader();
        reader.onload = function(e) {
            newProduct.image = e.target.result;
            products.push(newProduct);
            saveData();
            alert('Product added successfully!');
            showPage('browse');
        };
        reader.readAsDataURL(imageFile);
    } else {
        products.push(newProduct);
        saveData();
        alert('Product added successfully!');
        showPage('browse');
    }
    
    // Reset form
    document.getElementById('add-product-form').reset();
    document.getElementById('image-preview').innerHTML = '<i class="fas fa-image"></i><p>Click to add image</p>';
}

function handleImageUpload(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('image-preview');
            preview.innerHTML = `<img src="${e.target.result}" alt="Product preview">`;
        };
        reader.readAsDataURL(file);
    }
}

function handleEditProfile(e) {
    e.preventDefault();
    
    const username = document.getElementById('edit-username').value;
    const email = document.getElementById('edit-email').value;
    const password = document.getElementById('edit-password').value;
    
    if (currentUser) {
        currentUser.username = username;
        currentUser.email = email;
        if (password) {
            currentUser.password = password;
        }
        
        // Update in users array
        const userIndex = users.findIndex(user => user.id === currentUser.id);
        if (userIndex !== -1) {
            users[userIndex] = currentUser;
        }
        
        saveData();
        updateUI();
        closeModal();
        alert('Profile updated successfully!');
    }
}

// Product Management
function loadProducts() {
    console.log('Loading products...', products.length, 'products found');
    const productsGrid = document.getElementById('products-grid');
    if (!productsGrid) {
        console.error('Products grid not found!');
        return;
    }
    
    productsGrid.innerHTML = '';
    
    if (products.length === 0) {
        productsGrid.innerHTML = '<p style="text-align: center; color: #666; font-size: 1.2rem; padding: 2rem;">No products found. <a href="#" onclick="showPage(\'add-product\')">Add the first product!</a></p>';
        return;
    }
    
    products.forEach((product, index) => {
        console.log(`Creating card for product ${index + 1}:`, product.title, 'Image:', product.image ? 'Yes' : 'No');
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
    
    console.log('Products loaded successfully');
}

function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.onclick = () => showProductDetail(product.id);
    
    const imageHtml = product.image ? 
        `<img src="${product.image}" alt="${product.title}" style="width: 100%; height: 100%; object-fit: cover;">` : 
        '<i class="fas fa-image"></i>';
    
    card.innerHTML = `
        <div class="product-image">
            ${imageHtml}
        </div>
        <div class="product-info">
            <div class="product-title">${product.title}</div>
            <div class="product-price">$${product.price.toFixed(2)}</div>
            <div class="product-category">${product.category}</div>
        </div>
    `;
    
    return card;
}

function showProductDetail(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const container = document.getElementById('product-detail-container');
    const imageHtml = product.image ? 
        `<img src="${product.image}" alt="${product.title}" style="width: 100%; height: 100%; object-fit: cover;">` : 
        '<i class="fas fa-image"></i>';
    
    container.innerHTML = `
        <div class="product-detail-image">
            ${imageHtml}
        </div>
        <div class="product-detail-info">
            <h1 class="product-detail-title">${product.title}</h1>
            <div class="product-detail-price">$${product.price.toFixed(2)}</div>
            <div class="product-detail-category">Category: ${product.category}</div>
            <p class="product-detail-description">${product.description}</p>
            <button class="add-to-cart-btn" onclick="addToCart(${product.id})">Add to Cart</button>
        </div>
    `;
    
    showPage('product-detail');
}

function addToCart(productId) {
    if (!currentUser) {
        alert('Please login to add items to cart!');
        return;
    }
    
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const existingItem = cart.find(item => item.productId === productId);
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            productId: productId,
            quantity: 1,
            addedAt: new Date().toISOString()
        });
    }
    
    saveData();
    alert('Product added to cart!');
}

function loadCart() {
    const cartContainer = document.getElementById('cart-container');
    cartContainer.innerHTML = '';
    
    if (cart.length === 0) {
        cartContainer.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }
    
    let total = 0;
    
    cart.forEach(cartItem => {
        const product = products.find(p => p.id === cartItem.productId);
        if (!product) return;
        
        const itemTotal = product.price * cartItem.quantity;
        total += itemTotal;
        
        const cartItemElement = document.createElement('div');
        cartItemElement.className = 'cart-item';
        cartItemElement.innerHTML = `
            <div class="cart-item-image">
                ${product.image ? `<img src="${product.image}" alt="${product.title}">` : '<i class="fas fa-image"></i>'}
            </div>
            <div class="cart-item-info">
                <div class="cart-item-title">${product.title}</div>
                <div class="cart-item-price">$${product.price.toFixed(2)} x ${cartItem.quantity}</div>
            </div>
            <button class="remove-from-cart-btn" onclick="removeFromCart(${cartItem.productId})">Remove</button>
        `;
        
        cartContainer.appendChild(cartItemElement);
    });
    
    const totalElement = document.createElement('div');
    totalElement.className = 'cart-total';
    totalElement.innerHTML = `
        <h3>Total: $${total.toFixed(2)}</h3>
        <button class="submit-btn" onclick="checkout()">Checkout</button>
    `;
    
    cartContainer.appendChild(totalElement);
}

function removeFromCart(productId) {
    cart = cart.filter(item => item.productId !== productId);
    saveData();
    loadCart();
}

function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }
    
    // Add items to purchases
    cart.forEach(cartItem => {
        const product = products.find(p => p.id === cartItem.productId);
        if (product) {
            purchases.push({
                ...product,
                purchaseDate: new Date().toISOString(),
                quantity: cartItem.quantity
            });
        }
    });
    
    // Clear cart
    cart = [];
    saveData();
    
    alert('Purchase completed successfully!');
    showPage('purchases');
}

// My Listings Management
function loadMyListings() {
    if (!currentUser) {
        alert('Please login to view your listings!');
        return;
    }
    
    const myListingsGrid = document.getElementById('my-listings-grid');
    myListingsGrid.innerHTML = '';
    
    const userListings = products.filter(product => product.sellerId === currentUser.id);
    
    if (userListings.length === 0) {
        myListingsGrid.innerHTML = '<p>You have no listings yet. <a href="#" onclick="showPage(\'add-product\')">Add your first product!</a></p>';
        return;
    }
    
    userListings.forEach(product => {
        const listingCard = document.createElement('div');
        listingCard.className = 'product-card';
        
        listingCard.innerHTML = `
            <div class="product-image">
                ${product.image ? `<img src="${product.image}" alt="${product.title}">` : '<i class="fas fa-image"></i>'}
            </div>
            <div class="product-info">
                <div class="product-title">${product.title}</div>
                <div class="product-price">$${product.price.toFixed(2)}</div>
                <div class="product-category">${product.category}</div>
                <div class="listing-actions">
                    <button class="edit-btn" onclick="editProduct(${product.id})">Edit</button>
                    <button class="delete-btn" onclick="deleteProduct(${product.id})">Delete</button>
                </div>
            </div>
        `;
        
        myListingsGrid.appendChild(listingCard);
    });
}

function editProduct(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    // Fill form with product data
    document.getElementById('product-title').value = product.title;
    document.getElementById('product-category').value = product.category;
    document.getElementById('product-description').value = product.description;
    document.getElementById('product-price').value = product.price;
    
    // Show add product page
    showPage('add-product');
    
    // Update form submission to handle edit
    const form = document.getElementById('add-product-form');
    form.onsubmit = function(e) {
        e.preventDefault();
        updateProduct(productId);
    };
}

function updateProduct(productId) {
    const title = document.getElementById('product-title').value;
    const category = document.getElementById('product-category').value;
    const description = document.getElementById('product-description').value;
    const price = parseFloat(document.getElementById('product-price').value);
    const imageFile = document.getElementById('product-image').files[0];
    
    const productIndex = products.findIndex(p => p.id === productId);
    if (productIndex !== -1) {
        products[productIndex].title = title;
        products[productIndex].category = category;
        products[productIndex].description = description;
        products[productIndex].price = price;
        
        if (imageFile) {
            const reader = new FileReader();
            reader.onload = function(e) {
                products[productIndex].image = e.target.result;
                saveData();
                alert('Product updated successfully!');
                showPage('my-listings');
            };
            reader.readAsDataURL(imageFile);
        } else {
            saveData();
            alert('Product updated successfully!');
            showPage('my-listings');
        }
    }
    
    // Reset form
    document.getElementById('add-product-form').reset();
    document.getElementById('image-preview').innerHTML = '<i class="fas fa-image"></i><p>Click to add image</p>';
}

function deleteProduct(productId) {
    if (confirm('Are you sure you want to delete this product?')) {
        products = products.filter(p => p.id !== productId);
        saveData();
        loadMyListings();
        alert('Product deleted successfully!');
    }
}

// Purchases Management
function loadPurchases() {
    if (!currentUser) {
        alert('Please login to view your purchases!');
        return;
    }
    
    const purchasesContainer = document.getElementById('purchases-container');
    purchasesContainer.innerHTML = '';
    
    if (purchases.length === 0) {
        purchasesContainer.innerHTML = '<p>You have no previous purchases.</p>';
        return;
    }
    
    purchases.forEach(purchase => {
        const purchaseItem = document.createElement('div');
        purchaseItem.className = 'purchase-item';
        purchaseItem.innerHTML = `
            <div class="purchase-item-image">
                ${purchase.image ? `<img src="${purchase.image}" alt="${purchase.title}">` : '<i class="fas fa-image"></i>'}
            </div>
            <div class="purchase-item-info">
                <div class="purchase-item-title">${purchase.title}</div>
                <div class="purchase-item-price">$${purchase.price.toFixed(2)}</div>
                <div class="purchase-date">Purchased: ${new Date(purchase.purchaseDate).toLocaleDateString()}</div>
            </div>
        `;
        
        purchasesContainer.appendChild(purchaseItem);
    });
}

// Dashboard Management
function loadDashboard() {
    if (!currentUser) {
        alert('Please login to view your dashboard!');
        return;
    }
    
    // Update profile info
    document.getElementById('profile-username').textContent = currentUser.username;
    document.getElementById('profile-email').textContent = currentUser.email;
    
    // Calculate stats
    const userListings = products.filter(product => product.sellerId === currentUser.id);
    const totalSpent = purchases.reduce((sum, purchase) => sum + purchase.price, 0);
    
    document.getElementById('total-listings').textContent = userListings.length;
    document.getElementById('total-purchases').textContent = purchases.length;
    document.getElementById('total-spent').textContent = `$${totalSpent.toFixed(2)}`;
}

function editProfile() {
    document.getElementById('edit-username').value = currentUser.username;
    document.getElementById('edit-email').value = currentUser.email;
    document.getElementById('edit-password').value = '';
    
    const modal = document.getElementById('edit-profile-modal');
    modal.style.display = 'block';
}

function closeModal() {
    const modal = document.getElementById('edit-profile-modal');
    modal.style.display = 'none';
}

// Search and Filter Functions
function searchProducts() {
    const searchTerm = document.getElementById('search-input').value.toLowerCase();
    const filteredProducts = products.filter(product => 
        product.title.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm)
    );
    
    displayFilteredProducts(filteredProducts);
}

function filterByCategory(category) {
    // Update active filter button
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    const filteredProducts = category === 'all' 
        ? products 
        : products.filter(product => product.category === category);
    
    displayFilteredProducts(filteredProducts);
}

function displayFilteredProducts(filteredProducts) {
    const productsGrid = document.getElementById('products-grid');
    productsGrid.innerHTML = '';
    
    filteredProducts.forEach(product => {
        const productCard = createProductCard(product);
        productsGrid.appendChild(productCard);
    });
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('edit-profile-modal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}

// Force refresh function for debugging
function forceRefresh() {
    console.log('Force refreshing...');
    localStorage.clear();
    location.reload();
}

// Navigation History Functions
function addToNavigationHistory(pageId) {
    // Remove any future history if we're not at the end
    if (currentHistoryIndex < navigationHistory.length - 1) {
        navigationHistory = navigationHistory.slice(0, currentHistoryIndex + 1);
    }
    
    // Add new page to history
    navigationHistory.push(pageId);
    currentHistoryIndex = navigationHistory.length - 1;
    
    // Limit history size
    if (navigationHistory.length > 10) {
        navigationHistory.shift();
        currentHistoryIndex--;
    }
    
    console.log('Navigation history:', navigationHistory, 'Current index:', currentHistoryIndex);
}

function goBack() {
    if (currentHistoryIndex > 0) {
        currentHistoryIndex--;
        const pageId = navigationHistory[currentHistoryIndex];
        showPage(pageId, false); // Don't add to history when going back
    }
}

function goForward() {
    if (currentHistoryIndex < navigationHistory.length - 1) {
        currentHistoryIndex++;
        const pageId = navigationHistory[currentHistoryIndex];
        showPage(pageId, false); // Don't add to history when going forward
    }
}

function refreshCurrentPage() {
    const currentPage = getCurrentPage();
    if (currentPage) {
        showPage(currentPage, false);
    }
}

function getCurrentPage() {
    const activePage = document.querySelector('.page.active');
    if (activePage) {
        return activePage.id.replace('-page', '');
    }
    return null;
}

function updateBreadcrumb(pageId) {
    const breadcrumb = document.getElementById('breadcrumb');
    const currentPageElement = document.getElementById('current-page');
    
    if (!breadcrumb || !currentPageElement) return;
    
    const pageNames = {
        'home': 'Home',
        'browse': 'Browse Products',
        'my-listings': 'My Listings',
        'cart': 'Shopping Cart',
        'purchases': 'Purchase History',
        'dashboard': 'Dashboard',
        'login': 'Login',
        'add-product': 'Add Product',
        'product-detail': 'Product Details'
    };
    
    const pageName = pageNames[pageId] || pageId;
    currentPageElement.textContent = pageName;
    
    // Update breadcrumb with history
    let breadcrumbHtml = '';
    for (let i = 0; i <= currentHistoryIndex; i++) {
        const historyPageId = navigationHistory[i];
        const historyPageName = pageNames[historyPageId] || historyPageId;
        const isActive = i === currentHistoryIndex;
        
        breadcrumbHtml += `<span class="breadcrumb-item ${isActive ? 'active' : ''}" onclick="goToHistoryIndex(${i})">${historyPageName}</span>`;
        
        if (i < currentHistoryIndex) {
            breadcrumbHtml += '<span class="breadcrumb-separator">›</span>';
        }
    }
    
    breadcrumb.innerHTML = breadcrumbHtml;
}

function goToHistoryIndex(index) {
    if (index >= 0 && index < navigationHistory.length) {
        currentHistoryIndex = index;
        const pageId = navigationHistory[index];
        showPage(pageId, false);
    }
}

function updateNavigationButtons() {
    const backBtn = document.querySelector('.nav-back');
    const forwardBtn = document.querySelector('.nav-forward');
    
    if (backBtn) {
        backBtn.disabled = currentHistoryIndex <= 0;
    }
    
    if (forwardBtn) {
        forwardBtn.disabled = currentHistoryIndex >= navigationHistory.length - 1;
    }
}

// Keyboard shortcuts for navigation
document.addEventListener('keydown', function(event) {
    // Alt + Left Arrow = Go Back
    if (event.altKey && event.key === 'ArrowLeft') {
        event.preventDefault();
        goBack();
    }
    
    // Alt + Right Arrow = Go Forward
    if (event.altKey && event.key === 'ArrowRight') {
        event.preventDefault();
        goForward();
    }
    
    // F5 or Ctrl+R = Refresh current page
    if (event.key === 'F5' || (event.ctrlKey && event.key === 'r')) {
        event.preventDefault();
        refreshCurrentPage();
    }
    
    // Escape = Go back to previous page
    if (event.key === 'Escape') {
        goBack();
    }
});

// Add refresh button to home page
document.addEventListener('DOMContentLoaded', function() {
    // Add a refresh button to the home page for debugging
    const heroContent = document.querySelector('.hero-content');
    if (heroContent) {
        const refreshBtn = document.createElement('button');
        refreshBtn.textContent = '🔄 Refresh Data';
        refreshBtn.style.cssText = 'background: rgba(255,255,255,0.2); color: white; border: 2px solid white; padding: 0.5rem 1rem; margin-left: 1rem; border-radius: 25px; cursor: pointer;';
        refreshBtn.onclick = forceRefresh;
        heroContent.appendChild(refreshBtn);
    }
    
    // Initialize navigation history with current page
    const currentPage = getCurrentPage();
    if (currentPage) {
        addToNavigationHistory(currentPage);
    }
});
